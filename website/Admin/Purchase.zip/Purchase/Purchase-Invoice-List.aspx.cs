﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class Admin_Purchase_Purchase_Invoice_List : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bind_Invoice_grdView();
        }

    }



    //protected void btnSearch_Click(object sender, EventArgs e)
    //{
    //    Bind_Job_grdView();
    //}

    private void Bind_Invoice_grdView()
    {

        //string Query = string.Empty;      
        //Query = "select * from [View_JobPosting]";
        //string whereConcatenator = "WHERE ";


        //if (drdSearch.SelectedValue == "Name")
        //{
        //    Query += whereConcatenator;
        //    Query += "Name like'" + txtSearchValue.Text + "%'";
        //    whereConcatenator = "and ";
        //}


        //if (drdSearch.SelectedValue == "Mobile")
        //{
        //    Query += whereConcatenator;
        //    Query += "Mobile like'" + txtSearchValue.Text + "%'";
        //    whereConcatenator = "and ";
        //}

        //else if (drdSearch.SelectedValue == "CompanyName")
        //{
        //    Query += whereConcatenator;
        //    Query += "CompanyName like'" + txtSearchValue.Text + "%'";
        //    whereConcatenator = "and ";
        //}




        //if (txtOpendate.Text != string.Empty)
        //{
        //    Query += whereConcatenator;
        //    Query += "cast(jobopen_Date as date)='" + Convert.ToDateTime(txtOpendate.Text) + "'";
        //    whereConcatenator = " and ";
        //}

        //if (txtClosedate.Text != string.Empty)
        //{
        //    Query += whereConcatenator;
        //    Query += "cast(jobClose_Date as date)='" + Convert.ToDateTime(txtClosedate.Text) + "'";
        //    whereConcatenator = " and ";
        //}



        //Query += whereConcatenator + "JobCategory!='JobSheeker' ";
        //Query += " order by [job_Id] desc ";

        //DataTable dt = DataAccess.GetData(Query);


         DataTable dt = DataAccess.GetData("select * from [View_PurchaseInvoice] order by [PurchaseId] desc");
        if (dt.Rows.Count > 0 && dt != null)
        {
            grdView.DataSource = dt;
            grdView.DataBind();

            int TotalPage = dt.Rows.Count;
            CustPager.TotalRecords = TotalPage;
            CustPager.TotalPage = TotalPage % grdView.PageSize == 0 ? TotalPage / grdView.PageSize : TotalPage / grdView.PageSize + 1;
        }
    }
    protected void CustPager_PageChanged(object sender, CustomPageChangeArgs e)
    {
        grdView.PageSize = e.CurrentPageSize;
        grdView.PageIndex = e.CurrentPageNumber - 1;
        Bind_Invoice_grdView();   //bindBranchList();
        CustPager.Reload();

    }
    protected void Edit(object sender, ImageClickEventArgs e)
    {
        ImageButton btndetails = sender as ImageButton;
        GridViewRow grdView = (GridViewRow)btndetails.NamingContainer;

        int ID = Convert.ToInt32(((HiddenField)grdView.FindControl("hdfID")).Value);

        if (btndetails.ID.Equals("imgbtnUpdate"))
        {
            Response.Redirect("PurchaseInvoice.aspx?PInVID=" + ID);

        }
        else if (btndetails.ID.Equals("imgbtnDelete"))
        {

            SqlCommand cmd = new SqlCommand("DELETE FROM [Purchase_Invoice]  WHERE  [PurchaseId] =" + ID + "");
            DataAccess.InsertExecuteNonQuery(cmd);


        }
        Bind_Invoice_grdView();
        CustPager.Reload();
    }




    protected void lnkExcel_Click(object sender, EventArgs e)
    {
        ExportGridToExcel();
    }


    private void ExportGridToExcel()
    {

        grdView.Columns[5].Visible = false;
        grdView.Columns[7].Visible = false;
        grdView.Columns[8].Visible = false;


        Response.Clear();
        Response.Buffer = true;
        Response.ClearContent();
        Response.ClearHeaders();
        Response.Charset = "";
        string FileName = "InvoiceFile" + DateTime.Now + ".xls";
        StringWriter strwritter = new StringWriter();
        HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
        Response.Cache.SetCacheability(HttpCacheability.NoCache);


        grdView.Columns[5].Visible = false;
        grdView.Columns[7].Visible = false;
        grdView.Columns[8].Visible = false;


        Response.ContentType = "application/vnd.ms-excel";
        Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
        grdView.GridLines = GridLines.Both;
        grdView.HeaderStyle.Font.Bold = true;
        grdView.RenderControl(htmltextwrtter);
        Response.Write(strwritter.ToString());
        Response.End();

    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        //required to avoid the runtime error "  
        //Control 'GridView1' of type 'GridView' must be placed inside a form tag with runat=server."  
    }


}